*   Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
Aliquam hendrerit mi posuere lectus. Vestibulum enim wisi,
viverra nec, fringilla in, laoreet vitae, risus.
*   Donec sit amet nisl. Aliquam semper ipsum sit amet velit.
Suspendisse id sem consectetuer libero luctus adipiscing.


*   Lorem ipsum dolor sit amet, consectetuer adipiscing elit.

*   Donec sit amet nisl. Aliquam semper ipsum sit amet velit.

1. Item one.
2. Item two with some code:
       code one


1. Item one.

2. Paragraph 1

   Paragraph 2

3. Item three with code:

       code two

Paragraph.

- line1
line2

  line1
line2

  line1
line2
line3
line4

line 5