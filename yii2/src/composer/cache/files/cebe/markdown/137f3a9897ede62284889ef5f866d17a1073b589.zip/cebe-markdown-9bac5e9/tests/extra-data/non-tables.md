Non-tables
----------

This line contains two pipes but is not a table. [[yii\widgets\DetailView|DetailView]] widget displays the details of a single data [[yii\widgets\DetailView::$model|model]].
 
the line above contains a space.

looks | like | head
-:

looks | like | head
-:
a
