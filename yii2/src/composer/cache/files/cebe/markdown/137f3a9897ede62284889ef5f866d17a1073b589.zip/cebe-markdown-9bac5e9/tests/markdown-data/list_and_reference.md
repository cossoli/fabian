link [ref1]

- item 1 [ref2]
- item 2

  [ref1]: http://example.com/a
[ref2]: http://example.com/b


- item 1 [ref2]
- item 2

    [ref3]: http://example.com/a
