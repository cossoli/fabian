## Ordered, start's with 4

Tight:

4.	Four
5.	Five

and:

4. Four
5. Five
6. Six


Loose using tabs, start's with 5:

5.	Five

6.	Six

7.	Seven

and using spaces:

5. Five

6. Six

7. Seven

Multiple paragraphs, start's with 5:

5.	Item 1, graf one.

	Item 2. graf two. The quick brown fox jumped over the lazy dog's
	back.

6.	Item 2.

7.	Item 3.

## Nested, start's with 5

5. Five
6. Six:
	* Fee
	* Fie
	* Foe
7. Seven

Same thing but with paragraphs:

5. Five

6. Six:

	* Fee
	* Fie
	* Foe

7. Seven

