this is __strong__ and this is **strong**.

this is _em_ and this is *em*.

_`code`_ __`code`__

*`code`**`code`**`code`*

Hey *this is
italic*

Hey **this is
bold**

**strong text***emphasized text*

*emphasized text***strong text**

**strong text**_emphasized text_

*emphasized text*__strong text__

__strong text__*emphasized text*

_emphasized text_**strong text**

simple_word_with_underscores

this is text, _this is emph_ simple_word_with_underscores text again.

highlight something in**side** of a word. a**b**c.

a ** a\*b **

a __ a\_b __

a * a\*b *

a _ a\_b _

a **this *is* strong**

a *this **is** strong*

a ***this is strong***

a **\* ABC**

a **A****B**

a **A____B**

a __A____B__

a __A****B__

5 * 4 = 20

**

aha * * haha

_em\_text_ __strong\_\_text\___

*em\*text* **strong\*\*text\***
