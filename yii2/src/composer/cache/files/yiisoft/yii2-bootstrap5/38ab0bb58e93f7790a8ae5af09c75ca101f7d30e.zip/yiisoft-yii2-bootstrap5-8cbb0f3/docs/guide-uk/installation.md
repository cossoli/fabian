Встановлення
============

## Отримання пакету Composer

Кращим способом для встановлення даного розширення є встановлення через [composer](http://getcomposer.org/download/).

Запустіть

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

або додайте

```
"yiisoft/yii2-bootstrap": "~1.0.0"
```

до потрібного розділу вашого файлу `composer.json`.
