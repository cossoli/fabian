安装
============

## 获取 Composer 包

安装此扩展的首选方式是通过 [composer](http://getcomposer.org/download/).

直接运行

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

或者在项目目录的 `composer.json` 文件中添加如下代码

```
"yiisoft/yii2-bootstrap": "~1.0.0"
```
