Installation
============

## Getting Composer package

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

Either run

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

or add

```
"yiisoft/yii2-bootstrap5": "~1.0.0"
```

to the require section of your `composer.json` file.
